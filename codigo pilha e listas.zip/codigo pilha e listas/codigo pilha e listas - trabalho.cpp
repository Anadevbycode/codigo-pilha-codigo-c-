#include <iostream>

using namespace std;

template <typename T>
class Stack {
 public:
  Stack() : top_(-1), capacity_(0), array_(nullptr) {}

  explicit Stack(int capacity) : top_(-1), capacity_(capacity), array_(new T[capacity]) {}

  ~Stack() {
    if (array_ != nullptr) {
      delete[] array_;
    }
  }

  bool isEmpty() const { return top_ == -1; }

  bool isFull() const { return top_ == capacity_ - 1; }

  void push(T value) {
    if (isFull()) {
      cout << "A pilha est� cheia!" << endl;
      return;
    }

    array_[++top_] = value;
  }

  T pop() {
    if (isEmpty()) {
      cout << "A pilha est� vazia!" << endl;
      return T();
    }

    return array_[top_--];
  }

  void print() const {
    if (isEmpty()) {
      cout << "A pilha est� vazia!" << endl;
      return;
    }

    for (int i = top_; i >= 0; i--) {
      cout << array_[i] << " ";
    }
    cout << endl;
  }

 private:
  int top_;
  int capacity_;
  T *array_;
};

int main() {
  // Entrada do usu�rio
  int capacity;
  cout << "Informe o tamanho da pilha: ";
  cin >> capacity;

  // Inicializa��o da pilha
  Stack<int> stack(capacity);

  // Inser��o dos elementos na pilha
  for (int i = 0; i < capacity; i++) {
    int value;
    cout << "Informe o valor do elemento " << i + 1 << ": ";
    cin >> value;
    stack.push(value);
  }

  // Impress�o da pilha inicial
  stack.print();

  // Inclus�o de um elemento na pilha
  int value;
  cout << "Informe o valor do elemento a ser inserido: ";
  cin >> value;
  stack.push(value);

  // Impress�o da pilha ap�s a inclus�o
  stack.print();

  // Remo��o de um elemento da pilha
  int removedValue = stack.pop();
  cout << "O elemento removido foi " << removedValue << endl;

  // Impress�o da pilha ap�s a remo��o
  stack.print();

  return 0;
}
